## Scrippy
Scrippy is a Chrome and Firefox browser extension that stores SQL statments (more in the future) to aid in the testing of websites for code injection vulnerbulities. Think cheat sheets but all you do is right click for them.  

This tool is made for web developers and pen testers that want to test sites/have legal authorisation to work on for SQL and XSS injections (and what other types of attacks get implemented into this tool). I will not be held responsible (and  for your at all in attacking websites that your not allowed and on top of that if this tool fucks up and attacks sites randomly then again i take no responsibility. 

PLease feel free to add more payloads to the ...payload files :)



## To do


###### Documentation:
* How to install
* How to use
* Examples and demos

###### Refactor code:
Core code base needs to be refactored 

###### SQL:
* ~~Right click -> SQL -> Quick predefinded statements~~ Needs more usful statements
* ~~Right click -> SQL -> Favorite statements~~ 
* ~~Set Favorites in options/popup menu page~~
* ~~Click popup menu -> SQL payloads -> list of Payloads~~ Completed Needs more payloads

###### XSS:
* Right click -> XSS -> Quick predefinded statements
* Right click -> XSS -> Favorite statements
* Set Favorites in options/popup menu page
* Click popup menu -> XSS payloads -> list of Payloads

###### Encoding:
* Select text -> right click it -> encode -> URL
* Select text -> right click it -> encode -> Base64 encode
* Select text -> right click it -> encode -> Double encode

###### SQL Map intergration:
* Right click on input -> SQL Map here -> open SQL mapper - With current element and basic command inputed.
* Get current element 
* Open SQL Mapper
* Input command         
